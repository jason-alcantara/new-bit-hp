<?php
/**
 * Features list start template
 */
?>
<div class="pricing-table__features">