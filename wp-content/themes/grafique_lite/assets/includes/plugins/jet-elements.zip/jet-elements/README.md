# Jet Elements For Elementor

Brand new addon for Elementor Page builder. It provides the set of modules to create different kinds of content, adds custom modules to your website and applies attractive styles in the matter of several clicks!

# ChangeLog

## [1.7.1.1](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.1.1)
* Added: Animation Prop type option for parallax items
* Fixed: cherry js core browser avaliable check

## [1.7.1](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.1)
* Added: Possibility to disable widgets that can be used
* Added: Adaptive height option to Testimonials widget
* Fixed: Block section scroling bug(OceanWp theme compatibility bug)

## [1.7.0.2](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.0.2)

* Fixed: Instagram request bug
* Fixed: Scroll Navi waypoint once trigger bug

## [1.7.0.1](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.0.1)

* Updated .pot file

## [1.7.0](https://github.com/ZemezLab/jet-elements/releases/tag/1.7.0)

* Added Consulting page template
* Added Beauty salon page template
* Car repair page template
